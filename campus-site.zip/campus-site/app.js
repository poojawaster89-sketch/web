/* ===== SITE SETTINGS — edit these ===== */
const SITE = {name:"Sticker Bomb", year:"2026", email:"yourname@example.com"};

/* ===== YOUR PHOTOS =====
   Put pictures in the "photos" folder. One line per photo.
   tag: "Trip" or "Festival"  |  album: the group heading it appears under */
const PHOTOS = [
  {src:"photos/goa-beach.jpg",    title:"Palolem sunset",  tag:"Trip",     album:"Goa Trip",     note:"Everyone went quiet for ten minutes", emoji:"🌅"},
  {src:"photos/bus-singalong.jpg",title:"Bus antakshari",  tag:"Trip",     album:"Goa Trip",     note:"Back seat, loudest row",              emoji:"🚌"},
  {src:"photos/shack.jpg",        title:"Shack lunch",     tag:"Trip",     album:"Goa Trip",     note:"Fish thali for nine",                 emoji:"🍤"},
  {src:"photos/fort-group.jpg",   title:"Summit squad",    tag:"Trip",     album:"Raigad Trek",  note:"Fog, then sun",                       emoji:"⛰️"},
  {src:"photos/campfire.jpg",     title:"Midnight maggi",  tag:"Trip",     album:"Raigad Trek",  note:"Campfire, 1 a.m.",                    emoji:"🔥"},
  {src:"photos/fest-stage.jpg",   title:"Main stage",      tag:"Festival", album:"Annual Fest",  note:"Day two headliner",                   emoji:"🎤"},
  {src:"photos/rangoli.jpg",      title:"Rangoli war",     tag:"Festival", album:"Annual Fest",  note:"Third-year hall won",                 emoji:"🎨"},
  {src:"photos/dance.jpg",        title:"Garba night",     tag:"Festival", album:"Navratri",     note:"Twelve circles deep",                 emoji:"💃"},
  {src:"photos/lamps.jpg",        title:"Diya wall",       tag:"Festival", album:"Navratri",     note:"Lit by the first years",              emoji:"🪔"}
];
/* ===== MEMORY NOTES (Memories page) ===== */
const NOTES = [
  {t:"Best bus ride of my life. Still hoarse.", by:"Aarti"},
  {t:"We lost the way up the fort and found the best view.", by:"Rohan"},
  {t:"Rangoli took six hours. Worth every colour.", by:"Sneha"},
  {t:"Garba shoes did not survive. Memories did.", by:"Kunal"}
];


/* ===== TEAM (Team page) — add photo file names in "src" if you have them ===== */
const TEAM=[
  {name:"Aarti",role:"Chief photographer",fun:"Has 4,000 photos of one sunset",emoji:"📸",src:""},
  {name:"Rohan",role:"Trip planner",fun:"Never once read the map",emoji:"🧭",src:""},
  {name:"Sneha",role:"Fest decorator",fun:"Owns every colour of chalk",emoji:"🎨",src:""},
  {name:"Kunal",role:"DJ and snack minister",fun:"Carries a speaker everywhere",emoji:"🎧",src:""}
];
/* ===== TIMELINE (Timeline page) — oldest first ===== */
const EVENTS=[
  {date:"Jan 2026",title:"Goa Trip",text:"Two nights, one bus and zero sleep.",emoji:"🏖️"},
  {date:"Feb 2026",title:"Annual Fest",text:"Three days of stages, food stalls and rangoli.",emoji:"🎤"},
  {date:"Aug 2026",title:"Raigad Trek",text:"Climbed through fog and ate maggi at the top.",emoji:"⛰️"},
  {date:"Oct 2026",title:"Navratri Nights",text:"Garba circles that kept getting bigger.",emoji:"💃"}
];
/* ===== VIDEOS (Videos page) — paste a YouTube video ID in "yt" (the part after v=) ===== */
const VIDEOS=[
  {title:"Goa trip recap",note:"Best bits from the bus and beach",yt:""},
  {title:"Fest highlights",note:"Stage, dance and rangoli in two minutes",yt:""},
  {title:"Trek diary",note:"Raigad from base to summit",yt:""}
];

const COL=["#ff3d8b","#ffe14d","#3de0a5","#ff7a29","#9b7bff","#2fd0ff"];
const GR=["linear-gradient(135deg,#ff3d8b,#ffe14d)","linear-gradient(135deg,#3de0a5,#2f4bff)","linear-gradient(135deg,#ff7a29,#ff3d8b)","linear-gradient(135deg,#9b7bff,#2fd0ff)"];
const SH=["50%","58% 42% 55% 45% / 48% 60% 40% 52%","200px 200px 18px 18px","30%","22px","45% 55% 40% 60% / 55% 45% 60% 40%"];
const W=[190,230,270,210,250], R=["1/1","4/5","5/4","1/1","3/4"];
const rnd=(a,b)=>a+Math.random()*(b-a);
PHOTOS.forEach((p,i)=>{p.g=GR[i%4];p.tc=COL[i%6];p.i=i});
const $=(s,r=document)=>r.querySelector(s);
function h(tag,cls,html){const e=document.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;return e}

/* ---- shared nav + footer ---- */
const PAGES=[["index.html","Home"],["trips.html","Trips"],["festivals.html","Festivals"],["timeline.html","Timeline"],["videos.html","Videos"],["team.html","Team"],["vote.html","Vote"],["memories.html","Memories"],["about.html","About"]];
const here=location.pathname.split("/").pop()||"index.html";
const nav=h("nav","nav");nav.setAttribute("aria-label","Main");
nav.innerHTML='<a class="logo" href="index.html">'+SITE.name+'</a>'+PAGES.map(([u,n])=>'<a class="l" href="'+u+'"'+(u===here?' aria-current="page"':'')+'>'+n+'</a>').join("");
document.body.prepend(nav);
document.body.append(h("footer",null,"© "+SITE.year+" "+SITE.name+" · made on campus, hosted on GitHub Pages"));

/* ---- stickers ---- */
function face(p){
  const t=h("span","face",p.emoji||"📷");
  if(!p.src)return t;
  const im=new Image();im.className="face";im.src=p.src;im.alt=p.title;im.loading="lazy";im.draggable=false;
  im.onerror=()=>im.replaceWith(t);return im;
}
function sticker(p,list,k){
  const el=h("button","stk");el.setAttribute("aria-label","Open "+p.title);
  el.style.cssText="--g:"+p.g+";--tc:"+p.tc+";--w:"+Math.min(W[p.i%5],innerWidth*.6)+"px;--ar:"+R[(p.i*3)%5]+";--sh:"+SH[(p.i+k)%6]+";--r:"+rnd(-8,8).toFixed(1)+"deg;--m:"+rnd(-6,14).toFixed(0)+"px "+rnd(-2,10).toFixed(0)+"px";
  el.append(face(p),h("span","tag",p.title));
  let sx,sy,ox,oy,moved;
  el.addEventListener("pointerdown",e=>{
    sx=e.clientX;sy=e.clientY;moved=false;ox=parseFloat(el.style.getPropertyValue("--dx"))||0;oy=parseFloat(el.style.getPropertyValue("--dy"))||0;
    el.setPointerCapture(e.pointerId);
    const mv=v=>{const dx=v.clientX-sx,dy=v.clientY-sy;if(!moved&&Math.hypot(dx,dy)>6){moved=true;el.classList.add("drag")}
      if(moved){el.style.setProperty("--dx",ox+dx+"px");el.style.setProperty("--dy",oy+dy+"px")}};
    const up=()=>{el.removeEventListener("pointermove",mv);el.removeEventListener("pointerup",up);el.classList.remove("drag");if(!moved)openLb(list,k)};
    el.addEventListener("pointermove",mv);el.addEventListener("pointerup",up);
  });
  el.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();openLb(list,k)}});
  return el;
}
function pile(list){const d=h("div","pile");list.forEach((p,k)=>d.append(sticker(p,list,k)));return d}

/* ---- lightbox ---- */
const lb=h("div");lb.id="lb";lb.setAttribute("role","dialog");lb.setAttribute("aria-modal","true");lb.setAttribute("aria-label","Photo viewer");
lb.innerHTML='<button class="x" aria-label="Close">✕</button><button class="arrow pv" aria-label="Previous">‹</button><div class="big"></div><div class="bubble"><b></b><span></span></div><button class="arrow nx" aria-label="Next">›</button>';
document.body.append(lb);
let L=[],c=0;
function show(){const p=L[c],b=$(".big",lb);b.innerHTML="";b.style.animation="none";void b.offsetWidth;b.style.animation="";b.style.setProperty("--g",p.g);b.append(face(p));
  $(".bubble b",lb).textContent=p.title;$(".bubble span",lb).textContent=p.album+" — "+p.note}
function openLb(list,k){L=list;c=k;show();lb.classList.add("open");$(".x",lb).focus()}
const step=d=>{c=(c+d+L.length)%L.length;show()},close=()=>lb.classList.remove("open");
$(".pv",lb).onclick=()=>step(-1);$(".nx",lb).onclick=()=>step(1);$(".x",lb).onclick=close;
lb.addEventListener("click",e=>{if(e.target===lb)close()});
document.addEventListener("keydown",e=>{if(!lb.classList.contains("open"))return;if(e.key==="Escape")close();if(e.key==="ArrowLeft")step(-1);if(e.key==="ArrowRight")step(1)});

/* ---- page builders (called from each page) ---- */
function albums(sel,tag){
  const root=$(sel),list=PHOTOS.filter(p=>p.tag===tag);
  [...new Set(list.map(p=>p.album))].forEach(a=>{
    const items=list.filter(p=>p.album===a),s=h("section","album");
    s.append(h("h2",null,a),h("span","say",items.length+" photos · drag them around, tap to open"),pile(items));root.append(s);
  });
}
function home(){
  const f=[...PHOTOS].sort(()=>Math.random()-.5).slice(0,5);
  $("#feat").append(pile(f));
  const n=a=>new Set(PHOTOS.map(p=>p.album)).size;
  $("#stats").innerHTML=[[PHOTOS.length,"photos"],[n(),"albums"],[PHOTOS.filter(p=>p.tag==="Trip").length,"trip shots"],[PHOTOS.filter(p=>p.tag==="Festival").length,"fest shots"]]
    .map(([a,b])=>'<div class="stat"><b>'+a+'</b>'+b+'</div>').join("");
}
function memories(){
  let mine=[];try{mine=JSON.parse(localStorage.getItem("notes")||"[]")}catch(e){}
  const grid=$("#notes"),all=()=>[...NOTES,...mine];
  const draw=()=>{grid.innerHTML="";all().forEach((n,i)=>{const e=h("div","note");e.style.cssText="--nc:"+COL[i%6]+";--r:"+((i*53)%9-4)+"deg";
    e.append(document.createTextNode(n.t));e.append(h("small",null,"— "+n.by));grid.append(e)})};
  draw();
  $("#nf").onsubmit=e=>{e.preventDefault();const t=$("#nt").value.trim(),by=$("#nb").value.trim()||"Someone";if(!t)return;
    mine.push({t,by});try{localStorage.setItem("notes",JSON.stringify(mine))}catch(x){}draw();e.target.reset()};
}
function contact(){
  $("#cf").onsubmit=e=>{e.preventDefault();const n=$("#cn").value,m=$("#cm").value;
    location.href="mailto:"+SITE.email+"?subject="+encodeURIComponent("Photo gallery message from "+n)+"&body="+encodeURIComponent(m)};
}

function team(){
  const g=$("#tm");TEAM.forEach((m,i)=>{
    const c=h("div","person");c.style.cssText="--c:"+COL[i%6]+";--r:"+((i*37)%7-3)+"deg";
    const av=h("div","avatar",m.emoji||"🙂");
    if(m.src){const im=new Image();im.src=m.src;im.alt=m.name;im.onerror=()=>im.remove();av.append(im)}
    c.append(av,h("b",null,m.name),h("span",null,m.role),h("small",null,"Fun fact: "+m.fun));g.append(c)});
}
function timeline(){
  const t=$("#tl");EVENTS.forEach((e,i)=>{
    const d=h("div","ev "+(i%2?"right":"left"));d.style.setProperty("--c",COL[i%6]);
    d.innerHTML='<div class="dot">'+e.emoji+'</div><div class="card"><small>'+e.date+'</small><b>'+e.title+'</b><p>'+e.text+'</p></div>';t.append(d)});
}
function videos(){
  const g=$("#vd");VIDEOS.forEach((v,i)=>{
    const c=h("div","vid");c.style.setProperty("--c",COL[i%6]);
    const box=h("div","screen");
    if(v.yt){box.innerHTML='<iframe src="https://www.youtube-nocookie.com/embed/'+v.yt+'" title="'+v.title+'" allowfullscreen loading="lazy"></iframe>'}
    else box.innerHTML='<span>▶</span><small>Add a YouTube ID in app.js</small>';
    c.append(box,h("b",null,v.title),h("span",null,v.note));g.append(c)});
}
function vote(){
  let votes={},mine="";try{votes=JSON.parse(localStorage.getItem("votes")||"{}");mine=localStorage.getItem("myvote")||""}catch(e){}
  const grid=$("#vg"),top=$("#top");
  const save=()=>{try{localStorage.setItem("votes",JSON.stringify(votes));localStorage.setItem("myvote",mine)}catch(e){}};
  const draw=()=>{
    grid.innerHTML="";
    PHOTOS.forEach((p,k)=>{
      const w=h("div","cand"),s=sticker(p,PHOTOS,k);s.style.setProperty("--m","8px");
      const b=h("button","btn",(mine===p.title?"♥ Your vote":"♡ Vote")+" · "+(votes[p.title]||0));
      if(mine===p.title)b.style.background="var(--pink)",b.style.color="#fff";
      b.onclick=()=>{if(mine===p.title)return;if(mine)votes[mine]=Math.max(0,(votes[mine]||1)-1);mine=p.title;votes[mine]=(votes[mine]||0)+1;save();draw()};
      w.append(s,b);grid.append(w)});
    const rank=[...PHOTOS].sort((a,b)=>(votes[b.title]||0)-(votes[a.title]||0)).slice(0,3);
    top.innerHTML=rank.map((p,i)=>'<div class="stat"><b>'+["🥇","🥈","🥉"][i]+'</b>'+p.title+'<br>'+(votes[p.title]||0)+' votes</div>').join("");
  };
  draw();
}
