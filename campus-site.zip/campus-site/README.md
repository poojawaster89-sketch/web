# Sticker Bomb photo gallery
Pages: index, trips, festivals, memories, about.
Upload this whole folder to a GitHub repo, then Settings > Pages > Deploy from branch (main, root).
Edit photos and your email in app.js. Put pictures in /photos.
